# Handoff: Client journey stage selector + hero grain

## Overview

Two changes to `/how-we-work/client-journey` in `mile42_site/site`:

1. **Replace the four `Card` tiles below the hero — and the four detail `Section`s that follow them — with one interactive card.** Four stages sit on a single ink line; selecting one opens that stage's full detail inside the same card. There is no separate "full stage" section anymore: all of the copy that lived in those four sections now lives in the panel.
2. **Even out the hero's grain.** The current texture is concentrated in one area and is too strong.

## About the design files

`Client Journey.dc.html` in this bundle is a **design reference built in HTML** — a prototype of the intended look and behavior, not production code to copy. Recreate it in the site's existing environment (React 19 + react-router + Tailwind 4, composing `src/components/primitives.jsx`).

`StageJourney.jsx` is different: it is written against **this codebase's own idiom** (theme tokens, `rounded-card`, `shadow-hard`, `font-eyebrow`, `text-body`, react-router `Link`) and is intended as a drop-in starting point. Review it against house patterns rather than trusting it blindly.

## Fidelity

**High-fidelity.** Colors, type, spacing, geometry and motion are all specified below and should be matched.

## Steps

### 1. Hero grain

`mile42_site/design/tokens/` has no grain token; the current hero texture comes from the design-system's `--grain-image` used at `center/cover`, which is why it pools in one area. Two problems, one fix:

- **Uneven:** `cover` scales one raster across a 1240×~420 band.
- **Too strong:** it renders at 30% opacity.

Add `grain-fine.png` (in this bundle, 256×256) to `site/public/`, then add a `Grain` component to `primitives.jsx` and put it inside the hero band. The tile is per-pixel noise, so it repeats with no visible seam at any band size:

```jsx
/** An even film of grain over a colour field. The band must be `relative`;
 *  content above it needs no z-index because the overlay is not positioned last. */
export function Grain({ opacity = 0.5, className = '' }) {
  return (
    <span
      aria-hidden="true"
      className={`pointer-events-none absolute inset-0 mix-blend-multiply ${className}`}
      style={{
        background: "url('/grain-fine.png') repeat",
        backgroundSize: '256px 256px',
        opacity,
      }}
    />
  )
}
```

`Section` needs `relative` when it carries grain, and the `Wrap` inside it needs `relative` so the copy sits above the film. Apply it to the hero band and the closing CTA band.

### 2. The stage selector

- Copy `StageJourney.jsx` into `site/src/components/`.
- Add the two keyframes and the easing variable to `site/src/styles/index.css` (see **Motion**).
- In `src/pages/ClientJourney.jsx`: delete the `STAGES` grid of `Card`s, and delete the four detail `Section`s (`01 · Leaves clarity` through `04 · Leaves capability and trust`) plus the now-unused `UNDERSTAND` / `DESIGN` / `BUILD` / `EVOLVE` arrays, `NumList` and `StatementCards` imports. Then:

```jsx
<Section band="surface">
  <Wrap>
    <H2 className="mb-3">Understand, design, build, evolve.</H2>
    <Body className="mb-14">
      Four stages on one line. Select a stage to read what it produces, and what you
      are left holding when it ends.
    </Body>
    <StageJourney Spot={Spot} />
    <Quote className="mt-14">
      The work is complete only when you are stronger for the next decision, build,
      or initiative.
    </Quote>
  </Wrap>
</Section>
```

`Spot` is passed in so the component does not need its own asset manifest; it renders the stage's spot illustration at 76px above "You leave with:". Pass `undefined` to omit illustrations.

The sections that stay: hero, this one, "The journey is the same. Where you enter is not.", and the closing CTA.

## Layout

One card: `rounded-card border border-ink bg-page shadow-hard`, vertical padding 40px, horizontal padding `clamp(18px, 2.4vw, 44px)`. `isolate` is required on it — see **Gotchas**.

**Stage row** — a 4-column grid inside the card. Each column: horizontal padding `clamp(10px, 1.4vw, 20px)`, bottom padding 34px, and a `border-l border-ink` on columns 2–4 (the guide's "one wide card divided by 1px ink rules"). Column contents, in order:

| Element | Spec |
| --- | --- |
| Stage name | `font-heading` bold, `clamp(19px, 1.9vw, 26px)` / **line-height 32px (fixed)**, margin-bottom 14px |
| Node | 30×30, `rounded-pill`, `border-ink`, `shadow-hard`, numeral in `font-eyebrow` 12px ink, centered |
| Intro | `text-body`, margin-top 18px |
| Outcome | `font-eyebrow text-eyebrow uppercase` ink, margin-top 14px |

**Journey line** — 1px ink, absolutely positioned across the row at `top: 61px`. That value is `32 (heading line box) + 14 (its margin) + 15 (half the node)`. If the heading's line-height or margin changes, recompute it; the nodes sit in normal flow and the line must pass through their centers.

**Open column field** — absolutely positioned in the column, `inset-x-0 top-[61px] bottom-0`, `-z-10`, `origin-top`, filled with the stage accent. Scales from `scale-y-0` to `scale-y-100`.

**Rule** — 1px ink, bleeds past the card padding with negative margins equal to `clamp(18px, 2.4vw, 44px)`, margin-bottom 30px. Same treatment on the closed-state hint's top border.

**Detail** — two columns, `minmax(0,1fr) minmax(0,1.1fr)`, gap 56px, items aligned to start. Left: eyebrow, `text-heading-2` heading, paragraphs, optional link. Right: spot illustration (76px), "YOU LEAVE WITH:" eyebrow, numbered list (`34px` numeral gutter, 14px gaps). Stage quote below both columns, margin-top 36px, max-width 44rem.

## Interactions & behavior

- Nothing is open on load. Clicking a stage opens it; clicking the open stage closes it. One stage open at a time.
- Tiles are real `<button>`s, so Enter/Space and focus come free — this is why the prototype's `role="button"` + `tabIndex` is not carried over. `aria-expanded` reflects state.
- The `:focus-visible` rule already in `styles/index.css` is the focus treatment. Do not suppress it.
- The closed state shows "Select a stage to open it." above a full-card rule.
- Below ~1240px every horizontal value scales (`clamp`) so the single row never starves; the heading's line-height stays pinned so the line/node geometry holds. The row does not wrap — if you decide it should below ~700px, the journey line has to be reworked, since it assumes one row.
- `motion-reduce` disables the field transition, the node press, and the list stagger.

## Motion

Easing everywhere: `cubic-bezier(.2, 0, 0, 1)`.

| What | Property | Duration |
| --- | --- | --- |
| Open column field | `transform: scaleY(0 → 1)`, `origin-top` | 380ms |
| Node press | `translateY(0 → 2px)`, shadow `0 4px 0 → 0 1px 0`, accent fill in | 180ms |
| Rule | `scaleX(0 → 1)`, `origin-left` | 440ms |
| List items | opacity 0→1, `translateY(8px → 0)` | 420ms, delays 260/320/380/440ms |

Add to `site/src/styles/index.css`:

```css
@theme {
  --ease-m42: cubic-bezier(0.2, 0, 0, 1);
}

@keyframes m42-draw-x {
  from { transform: scaleX(0); }
  to   { transform: scaleX(1); }
}

@keyframes m42-item {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: none; }
}
```

## State management

One state variable: `open`, either `null` or the stage index `0–3`. No data fetching; all copy is static and lives in the component's `STAGES` array, lifted verbatim from the current `ClientJourney.jsx` (stage titles, bodies, outcomes) and its four detail sections (eyebrows, headings, paragraphs, lists, quotes, the delivery-model link).

## Design tokens

All from `design/tokens/theme.css` unless noted.

| Role | Token | Value |
| --- | --- | --- |
| Ink (text, borders, shadow) | `--color-ink` | `#2f1e14` |
| Card fill | `--color-page` | `#ffffff` |
| Band behind the card | `--color-surface` | `#f9f4ec` |
| Eyebrow | `--color-accent` | `#0073f4` |
| Stage 01 field + node | `--color-orange` | `#ff5e00` |
| Stage 02 field + node | `--color-sky` | `#73e1ff` |
| Stage 03 field + node | `--color-mint` | `#c7ffb1` |
| Stage 04 field + node | `--color-gold` | `#fab600` |
| Radius, surfaces | `--radius-card` | `12px` |
| Radius, node | `--radius-pill` | pill |
| Shadow | `--shadow-hard` | `0 4px 0 #2f1e14` |
| Pressed shadow | — | `0 1px 0 #2f1e14` |

Spacing used: 10, 14, 18, 22, 30, 34, 36, 40, 56 px; card padding `clamp(18px, 2.4vw, 44px)`; column padding `clamp(10px, 1.4vw, 20px)`.

## Gotchas

- **`isolate` on the card is load-bearing.** The open column's field is a `-z-10` child; without a stacking context on the card it paints behind the card's own white background and disappears. This exact bug happened during design.
- **The panel's top corners must stay square** if you ever give the detail its own surface — a rounded corner meeting the column field is what made earlier connector attempts look broken. As shipped, the detail has no surface of its own, so this is moot.
- **Do not tile the design system's `grain-texture.jpg`.** It is not a seamless tile; repeating it shows patch seams. Use the noise tile in this bundle.
- Illustrations must sit in the flow, not absolutely positioned over the detail — they overlapped the list copy when positioned.

## Assets

- `grain-fine.png` — 256×256 per-pixel noise, generated for this handoff. Goes in `site/public/`.
- Stage spot illustrations are already in the repo (`src/assets/illustrations/`, via `Spot`): `lightbulb`, `gears`, `laptop`, `handshake`. Names in `STAGES[].spot` may need to match the manifest's keys.

## Files in this bundle

- `README.md` — this document.
- `StageJourney.jsx` — drop-in component for `site/src/components/`.
- `grain-fine.png` — the grain tile.
- `Client Journey.dc.html` — the HTML design reference (whole page, including hero, entry points and CTA). Open it in a browser to see the interaction and motion.
