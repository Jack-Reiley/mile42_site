import { useState } from 'react'
import { Link } from 'react-router'

/**
 * The client journey stage selector: four stages on one ink line inside a single
 * card, with the open stage's detail rendered in the same card below a full-width
 * rule. Replaces the four `Card` tiles AND the four detail `Section`s that used to
 * follow them on /how-we-work/client-journey.
 *
 * Geometry that must not drift: the journey line sits at 61px from the row's top
 * (h3 line box 32px + its 14px margin = 46, plus half the 30px node). If the
 * heading's line-height or margin changes, that constant changes with it.
 */

const EASE = 'cubic-bezier(.2,0,0,1)'

/* Fills are the illustration accent that matches each stage's spot drawing.
   Stage 03 uses mint, the theme's green from the laptop blob. */
const STAGES = [
  {
    n: '01',
    title: 'Understand',
    intro:
      'Build shared context: what outcome matters, why now, and where execution is breaking down',
    outcome: 'Leaves clarity',
    fill: 'bg-orange',
    spot: 'lightbulb',
    eyebrow: '01 · Leaves clarity',
    heading: 'Context before solutions.',
    paras: [
      'Most engagements go wrong here, quietly. The work starts before anyone has agreed what outcome matters, why it matters now, or where execution is actually breaking down.',
      'We spend real time on this. Not a discovery workshop that produces a summary of what you already told us, but enough depth to make better calls under uncertainty later.',
    ],
    items: [
      'What outcome matters, stated specifically enough to know whether it moved.',
      'Why now, and what happens if nothing changes.',
      'Where execution is breaking down today, which is often not where it appears to be.',
      'What constraints are real, and which ones are habits.',
    ],
    quote: 'Without context, technology work becomes guesswork.',
  },
  {
    n: '02',
    title: 'Design',
    intro:
      'Bring technology, architecture, delivery, and organizational reality together into a sound path',
    outcome: 'Leaves confidence',
    fill: 'bg-sky',
    spot: 'gears',
    eyebrow: '02 · Leaves confidence',
    heading: 'A path that survives contact with your organization.',
    paras: [
      'Design here means more than an architecture diagram. It means bringing the technology, the delivery approach, and the organizational reality together into something that can actually be executed by the people who will have to execute it.',
      'A design that ignores adoption, operating model, or delivery risk is not a design. It is a preference.',
    ],
    items: [
      'An architecture, with the tradeoffs named rather than assumed.',
      'A sequence, including what happens first and why.',
      'An honest read on effort, dependency, and risk.',
      'A view on what changes for the people doing the work, and what that will take.',
    ],
    quote:
      'You should finish this stage able to explain the plan to your own leadership without us in the room.',
  },
  {
    n: '03',
    title: 'Build',
    intro:
      'Engineer the systems, products, integrations, and workflows, and improve how the organization executes',
    outcome: 'Leaves results',
    fill: 'bg-mint',
    spot: 'laptop',
    eyebrow: '03 · Leaves results',
    heading: 'Working systems, and a better way of executing.',
    paras: [
      'This is where most of the money and most of the risk sit. We engineer the systems, products, integrations, and workflows, and we stay accountable for whether they work in production rather than whether they were delivered on schedule.',
      'Two things happen at once. The system gets built, and the way your organization executes gets better, because how the work is done is part of what we are delivering.',
    ],
    items: [
      'Systems in production, used by the people they were built for.',
      'Governance, testing, and documentation that exist because they were built in, not because someone remembered at the end.',
      'A team that understands what was built and why.',
    ],
    link: { to: '/how-we-work/delivery-model', label: 'See the delivery model' },
  },
  {
    n: '04',
    title: 'Evolve',
    intro:
      'You know more, operate better, reuse more, and can do something you could not do before',
    outcome: 'Leaves capability and trust',
    fill: 'bg-gold',
    spot: 'handshake',
    eyebrow: '04 · Leaves capability and trust',
    heading: 'You should be able to do something you could not do before.',
    paras: [
      'The last stage is the one most firms skip, because it is the one that reduces their future revenue.',
      'Evolve means you can operate, extend, and change what was built without depending on us for every decision. It means the patterns and reasoning stayed with your team. It means the next initiative starts from a stronger position than this one did.',
    ],
    items: [
      'Your team can change the system without calling us.',
      'The decisions and their rationale are documented somewhere your people will find them.',
      'What you learned is reusable on work we are not involved in.',
      'If you bring us back, it is because you chose to, not because you are stuck.',
    ],
    quote: 'We build capability, not dependence.',
  },
]

/* The card padding is the one value repeated in three places: the card itself and
   the two elements that have to bleed past it (the rule and the closed-state hint). */
const PAD = 'clamp(18px,2.4vw,44px)'

export default function StageJourney({ Spot }) {
  const [open, setOpen] = useState(null)
  const stage = open === null ? null : STAGES[open]

  return (
    /* `isolate` is required: the open column's field is a -z-10 child, and without a
       stacking context on the card it would paint behind the card's own background. */
    <div
      className="relative isolate rounded-card border border-ink bg-page shadow-hard py-10"
      style={{ paddingLeft: PAD, paddingRight: PAD }}
    >
      <div className="relative grid grid-cols-4">
        <span aria-hidden="true" className="absolute inset-x-0 top-[61px] h-px bg-ink" />

        {STAGES.map((s, i) => {
          const on = open === i
          return (
            <button
              key={s.n}
              type="button"
              aria-expanded={on}
              onClick={() => setOpen(on ? null : i)}
              className={`relative pb-[34px] text-left ${i ? 'border-l border-ink' : ''}`}
              style={{ paddingLeft: 'clamp(10px,1.4vw,20px)', paddingRight: 'clamp(10px,1.4vw,20px)' }}
            >
              {/* The connector: the open column's field runs from the journey line
                  down to the rule above the detail, so the two are one surface. */}
              <span
                aria-hidden="true"
                className={`absolute inset-x-0 bottom-0 top-[61px] -z-10 origin-top transition-transform motion-reduce:transition-none ${
                  on ? `scale-y-100 ${s.fill}` : 'scale-y-0'
                }`}
                style={{ transitionDuration: '380ms', transitionTimingFunction: EASE }}
              />

              <h3
                className="font-heading font-bold leading-8 text-ink mb-[14px]"
                style={{ fontSize: 'clamp(19px,1.9vw,26px)' }}
              >
                {s.title}
              </h3>

              {/* The CheckList badge from Lists.jsx, carrying the stage numeral.
                  Selected presses down and shrinks the shadow — the style guide's press state. */}
              <span
                className={`grid h-[30px] w-[30px] place-items-center rounded-pill border border-ink font-eyebrow text-eyebrow text-ink transition-all motion-reduce:transition-none ${
                  on ? `${s.fill} translate-y-[2px] shadow-[0_1px_0_var(--color-ink)]` : 'bg-page shadow-hard'
                }`}
                style={{ transitionDuration: '180ms', transitionTimingFunction: EASE }}
              >
                {s.n}
              </span>

              <p className="mt-[18px] text-body text-ink">{s.intro}</p>
              <span className="mt-[14px] block font-eyebrow text-eyebrow uppercase text-ink">
                {s.outcome}
              </span>
            </button>
          )
        })}
      </div>

      {stage === null ? (
        <p
          className="border-t border-ink pt-[22px] text-body text-ink"
          style={{ marginLeft: `calc(-1 * ${PAD})`, marginRight: `calc(-1 * ${PAD})`, paddingLeft: PAD, paddingRight: PAD }}
        >
          Select a stage to open it.
        </p>
      ) : (
        <div key={stage.n}>
          {/* The rule bleeds past the card padding: it is the card's own division
              between the stage row and the open detail. */}
          <span
            aria-hidden="true"
            className="mb-[30px] block h-px origin-left bg-ink animate-[m42-draw-x_440ms_var(--ease-m42)_both]"
            style={{ marginLeft: `calc(-1 * ${PAD})`, marginRight: `calc(-1 * ${PAD})` }}
          />

          <div className="grid gap-14 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] items-start">
            <div>
              <p className="mb-[10px] font-eyebrow text-eyebrow uppercase text-accent">{stage.eyebrow}</p>
              <h4 className="mb-[18px] font-heading text-heading-2 font-bold text-ink text-pretty">
                {stage.heading}
              </h4>
              {stage.paras.map((p, i) => (
                <p key={i} className={`text-body text-ink ${i ? '' : 'mb-[14px]'}`}>
                  {p}
                </p>
              ))}
              {stage.link ? (
                <Link
                  to={stage.link.to}
                  className="mt-[22px] inline-flex items-center gap-2 text-body font-semibold text-ink no-underline"
                >
                  {stage.link.label} <span aria-hidden="true">&#8250;</span>
                </Link>
              ) : null}
            </div>

            <div>
              {Spot ? <Spot name={stage.spot} decorative sizes="76px" className="mb-4 h-[76px] w-[76px] object-contain" /> : null}
              <p className="mb-4 font-eyebrow text-eyebrow uppercase text-ink">You leave with:</p>
              <ol className="flex flex-col gap-[14px]">
                {stage.items.map((text, i) => (
                  <li
                    key={text}
                    className="grid grid-cols-[34px_minmax(0,1fr)] gap-[10px] animate-[m42-item_420ms_var(--ease-m42)_both] motion-reduce:animate-none"
                    style={{ animationDelay: `${260 + i * 60}ms` }}
                  >
                    <span className="pt-[5px] font-eyebrow text-eyebrow text-accent">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="text-body text-ink">{text}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          {stage.quote ? (
            <p className="mt-9 max-w-[44rem] font-heading text-heading-3 font-bold text-ink text-pretty">
              {stage.quote}
            </p>
          ) : null}
        </div>
      )}
    </div>
  )
}
